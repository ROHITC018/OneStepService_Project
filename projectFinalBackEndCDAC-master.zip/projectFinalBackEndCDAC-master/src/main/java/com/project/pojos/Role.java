package com.project.pojos;

public enum Role {
		
		ADMIN,USER,CONTRACTOR,LABOUR
}
