package com.project.pojos;

public enum WorkType {
			CWORK,LWORK
}
