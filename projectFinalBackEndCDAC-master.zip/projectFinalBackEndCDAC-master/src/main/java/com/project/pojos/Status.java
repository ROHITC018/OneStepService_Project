package com.project.pojos;

public enum Status {
		
		COMPLETED,ONGOING,PENDING,ACCEPTED;
}
