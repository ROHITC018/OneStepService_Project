package com.project.dto;

public class UserDTO {

	
}
